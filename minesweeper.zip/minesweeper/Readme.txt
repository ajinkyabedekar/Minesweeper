To compile server typpe
gcc -pthread server.c -o server
./server

To compile client type
gcc client.c minesweeper.c -o game
./game
